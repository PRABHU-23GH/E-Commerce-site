const API_URL = "https://vmj26hwvmc.execute-api.us-east-1.amazonaws.com/nithu"; // API Gateway URL
let cart = [];

// ✅ Add item to cart
function addToCart(product, price) {
    const item = { 
        cartID: Date.now().toString(), // Unique cart ID
        productName: product, 
        price: price, 
        quantity: 1 
    };

    fetch(`${API_URL}/cart`, { 
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(item),
        mode: "cors"
    })
    .then(response => {
        if (!response.ok) throw new Error(`HTTP error! Status: ${response.status}`);
        return response.json();  
    })
    .then(data => {
        console.log("Add to Cart Raw Response:", data);
    
        let parsedBody = data.body ? JSON.parse(data.body) : data; // ✅ Fixed JSON parsing

        if (!parsedBody) throw new Error("Invalid response format!");

        console.log("Parsed Response Body:", parsedBody);
    
        if (parsedBody.message === "Item added to cart successfully!") { 
            cart.push(item);
            updateCart();
            alert("Item added to cart!");
        } else {
            alert("Failed to add item to cart: " + JSON.stringify(parsedBody));
        }
    })
    .catch(error => {
        console.error("Error adding to cart:", error);
        alert("Error adding item to cart!");
    });
}

// ✅ Remove item from cart
function removeFromCart(cartID) {
    fetch(`${API_URL}/cart`, { 
        method: "DELETE",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ cartID: cartID }),
        mode: "cors"
    })
    .then(response => {
        if (!response.ok) throw new Error(`HTTP error! Status: ${response.status}`);
        return response.json();
    })
    .then(data => {
        console.log("Remove from Cart Response:", data);

        const parsedBody = data.body ? JSON.parse(data.body) : data; // ✅ Fixed JSON parsing

        if (!parsedBody) throw new Error("Invalid response format!");

        if (parsedBody.message === "Item removed from cart") {
            cart = cart.filter(item => item.cartID !== cartID);
            updateCart();
            alert("Item removed from cart!");
        } else {
            alert("Failed to remove item: " + JSON.stringify(parsedBody));
        }
    })
    .catch(error => {
        console.error("Error removing from cart:", error);
        alert("Error removing item from cart!");
    });
}

// ✅ Fetch cart items from API
function fetchCart() {
    fetch(`${API_URL}/cart`, { mode: "cors" })
    .then(response => {
        if (!response.ok) throw new Error(`HTTP error! Status: ${response.status}`);
        return response.json();
    })
    .then(data => {
        console.log("Fetch Cart Response:", data);

        let parsedBody = data.body ? JSON.parse(data.body) : data; // ✅ Fixed JSON parsing

        if (!parsedBody.items || !Array.isArray(parsedBody.items)) {
            throw new Error("Invalid response format while fetching cart!");
        }

        cart = parsedBody.items;
        updateCart();
    })
    .catch(error => {
        console.error("Error fetching cart:", error);
        alert("Error fetching cart items! Check console for details.");
    });
}

// ✅ Update cart UI
function updateCart() {
    let cartCount = document.getElementById("cart-count");
    let cartContainer = document.getElementById("cart-items"); // Ensure this ID exists in HTML

    if (cartCount) {
        cartCount.textContent = `(${cart.length})`;
    }

    if (cartContainer) {
        cartContainer.innerHTML = ""; // Clear previous content

        if (cart.length === 0) {
            cartContainer.innerHTML = "<p>Your cart is empty!</p>";
            return;
        }

        cart.forEach(item => {
            let itemDiv = document.createElement("li");
            itemDiv.classList.add("cart-item");
            itemDiv.innerHTML = `
                ${item.productName} - Rs.${item.price}
                <button onclick="removeFromCart('${item.cartID}')">Remove</button>
            `;
            cartContainer.appendChild(itemDiv);
        });
    }
}

// ✅ Load cart on page load
window.onload = fetchCart;
fetch(API_URL)
    .then(response => {
        if (!response.ok) throw new Error(`HTTP error! Status: ${response.status}`);
        return response.json();
    })
    .then(data => console.log("Cart Data:", data))
    .catch(error => console.error("Error fetching cart:", error)); 
