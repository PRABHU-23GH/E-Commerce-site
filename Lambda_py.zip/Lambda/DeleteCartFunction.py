import json
import boto3

dynamodb = boto3.resource("dynamodb")
table = dynamodb.Table("CartTable")

def lambda_handler(event, context):
    try:
        method = event["httpMethod"]

        # ✅ Handle POST (Add item)
        if method == "POST":
            data = json.loads(event["body"])
            cartID = str(data["cartID"])
            productName = data["productName"]
            price = data["price"]
            quantity = data["quantity"]

            table.put_item(
                Item={"cartID": cartID, "productName": productName, "price": price, "quantity": quantity}
            )

            return {
                "statusCode": 200,
                "headers": {"Access-Control-Allow-Origin": "*"},
                "body": json.dumps({"message": "Item added to cart"})
            }
        
        # ✅ Handle GET (Fetch cart)
        elif method == "GET":
            response = table.scan()
            items = response.get("Items", [])

            return {
                "statusCode": 200,
                "headers": {"Access-Control-Allow-Origin": "*"},
                "body": json.dumps(items)
            }
        
        # ✅ Handle DELETE (Remove item)
        elif method == "DELETE":
            data = json.loads(event["body"])
            cartID = data["cartID"]

            table.delete_item(Key={"cartID": cartID})

            return {
                "statusCode": 200,
                "headers": {"Access-Control-Allow-Origin": "*"},
                "body": json.dumps({"message": "Item removed from cart"})
            }

    except Exception as e:
        return {
            "statusCode": 500,
            "headers": {"Access-Control-Allow-Origin": "*"},
            "body": json.dumps({"error": str(e)})
        }
