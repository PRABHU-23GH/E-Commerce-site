import json
import boto3

dynamodb = boto3.resource("dynamodb")
table = dynamodb.Table("CartTable")

def lambda_handler(event, context):
    try:
        print("Received event:", event)  # Debugging log
        
        # Ensure event["body"] is properly handled
        if isinstance(event["body"], str):  # Only parse if it's a string
            body = json.loads(event["body"])
        else:
            body = event["body"]  # Already a dict, no need to parse

        print("Parsed body:", body)  # Debugging log

        # Extract cart details
        cart_id = body.get("cartID")
        product_name = body.get("productName")
        price = body.get("price")
        quantity = body.get("quantity")

        if not all([cart_id, product_name, price, quantity]):
            raise ValueError("Missing required fields in request body")

        # Store the item in DynamoDB
        table.put_item(
            Item={
                "cartID": str(cart_id),  # Ensure strings for partition key
                "productName": str(product_name),
                "price": int(price),  # Ensure numeric values
                "quantity": int(quantity),
            }
        )

        response = {
            "statusCode": 200,
            "headers": {"Content-Type": "application/json"},
            "body": json.dumps({"message": "Item added to cart successfully!"}),
        }
        return response

    except Exception as e:
        print("Error:", str(e))  # Debugging log
        return {
            "statusCode": 500,
            "body": json.dumps({"error": str(e)}),
        }
